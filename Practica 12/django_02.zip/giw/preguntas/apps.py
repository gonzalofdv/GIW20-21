from django.apps import AppConfig


class PreguntasConfig(AppConfig):
    name = 'preguntas'
